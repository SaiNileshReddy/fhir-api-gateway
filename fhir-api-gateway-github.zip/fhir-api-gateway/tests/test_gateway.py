from fastapi.testclient import TestClient
from app.main import app
from app.auth import create_demo_token
client = TestClient(app)
def token(c="hospital-a"): return create_demo_token(c)
def test_health(): assert client.get("/health").status_code == 200
def test_auth_required(): assert client.get("/fhir/Patient/123").status_code == 401
def test_patient_read(): assert client.get("/fhir/Patient/123", headers={"Authorization":f"Bearer {token()}"}).status_code == 200
def test_lab_cannot_read_patient(): assert client.get("/fhir/Patient/123", headers={"Authorization":f"Bearer {token('lab-b')}"}).status_code == 403
def test_validation():
    r=client.post("/fhir/Patient",json={"resourceType":"Observation","id":"x"},headers={"Authorization":f"Bearer {token()}"})
    assert r.status_code == 400
