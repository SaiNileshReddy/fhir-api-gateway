# Synthetic Sandbox Data
All data in this project is synthetic demonstration data. No real patient/PHI data is included.
