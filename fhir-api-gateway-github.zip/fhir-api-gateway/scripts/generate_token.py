import sys
from app.auth import create_demo_token
print(create_demo_token(sys.argv[1] if len(sys.argv) > 1 else "hospital-a"))
