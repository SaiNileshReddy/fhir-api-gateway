# FHIR API Gateway

A GitHub-ready demonstration gateway for inbound FHIR-style requests. It demonstrates JWT authentication, client/resource authorization, per-client rate limiting, basic FHIR request validation, FHIR `OperationOutcome` errors, audit logging, synthetic sandbox data, tests, and Docker support.

> **Demo only:** This is not a production HIPAA/security/compliance implementation. Use synthetic data only. Production healthcare systems require formal security, privacy, interoperability, and compliance review.

## Architecture

```text
Healthcare Client
      |
      | HTTPS + Bearer JWT
      v
+-----------------------+
|     FHIR Gateway      |
|-----------------------|
| Authentication        |
| Authorization         |
| Rate Limiting         |
| FHIR Validation       |
| Audit Logging         |
+-----------+-----------+
            |
            v
   Synthetic FHIR Store
```

## Features
- JWT authentication for demo clients
- Scope-based authorization such as `Patient.read`
- Configurable rate limit (default 100 requests/minute/client)
- Basic FHIR-shaped resource validation
- FHIR `OperationOutcome` errors
- Audit logs that avoid request bodies and bearer tokens
- Synthetic Patient and Observation resources
- Automated tests
- Docker / Docker Compose

## Project structure

```text
fhir-api-gateway/
├── app/
│   ├── main.py
│   ├── auth.py
│   ├── authorization.py
│   ├── rate_limiter.py
│   ├── fhir_validator.py
│   ├── audit.py
│   └── sandbox_store.py
├── sandbox/
├── scripts/
├── tests/
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
├── .env.example
├── .gitignore
└── README.md
```

## Run locally

```bash
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

macOS/Linux:
```bash
source .venv/bin/activate
```

Install:
```bash
pip install -r requirements.txt
```

Copy `.env.example` to `.env`, set a strong `JWT_SECRET`, then run:

```bash
uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000/docs`.

## Demo clients

| Client | Scopes |
|---|---|
| hospital-a | `Patient.read`, `Observation.read`, `Patient.write` |
| lab-b | `Observation.read` |

Generate a token:

```bash
python scripts/generate_token.py hospital-a
python scripts/generate_token.py lab-b
```

## API examples

Read a Patient:

```bash
curl -H "Authorization: Bearer YOUR_TOKEN" http://127.0.0.1:8000/fhir/Patient/123
```

Search Patients:

```bash
curl -H "Authorization: Bearer YOUR_TOKEN" http://127.0.0.1:8000/fhir/Patient
```

Create a synthetic Patient:

```bash
curl -X POST \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{"resourceType":"Patient","id":"789","active":true}' \
  http://127.0.0.1:8000/fhir/Patient
```

Lab B attempting Patient access returns `403` because it lacks `Patient.read`.

## Rate limiting

Default: `100 requests / 60 seconds / client`.

Set `RATE_LIMIT=3` for a quick demo, restart the server, and send four requests. The fourth should return HTTP `429` with an `OperationOutcome`.

## FHIR validation

The demo checks JSON structure, `resourceType`, required demo fields, endpoint/resource-type matching, and an ID for PUT. For production, replace this with a standards-compliant FHIR validation engine and the required profiles/Implementation Guides.

## Audit logging

Logs include timestamp, client ID, method, path, resource type/ID, decision, and status. Request bodies and bearer tokens are deliberately not logged.

## Tests

```bash
pytest -q
```

## Docker

```bash
docker compose up --build
```

Gateway: `http://localhost:8000`

## Production hardening checklist

1. Use OAuth 2.0 / SMART on FHIR with a real authorization server.
2. Validate JWTs with issuer, audience, expiry, and JWKS/asymmetric signatures.
3. Enforce TLS and appropriate mTLS controls.
4. Validate the exact FHIR version and implementation profiles required by the environment.
5. Support tenant isolation and organization-level authorization.
6. Use distributed rate limiting (e.g. Redis/API gateway infrastructure).
7. Centralize immutable security audit logs with appropriate retention.
8. Use a secrets manager; never commit credentials.
9. Add request-size limits, timeouts, replay protection, monitoring, and alerting.
10. Minimize/redact PHI in logs and traces.
11. Complete formal privacy, security, interoperability, and regulatory review before real healthcare data is processed.

## GitHub upload

After extracting this project:

```bash
git init
git add .
git commit -m "Initial FHIR API Gateway"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

Do not commit `.env`, production credentials, real patient data, access tokens, or other confidential information.
