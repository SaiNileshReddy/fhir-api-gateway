import os
from fastapi import Request
from jose import jwt, JWTError

JWT_SECRET = os.getenv("JWT_SECRET", "change-this-demo-secret")
JWT_ALGORITHM = "HS256"
CLIENTS = {
    "hospital-a": {"client_id": "hospital-a", "name": "Hospital A", "scopes": ["Patient.read", "Observation.read", "Patient.write"]},
    "lab-b": {"client_id": "lab-b", "name": "Lab B", "scopes": ["Observation.read"]},
}

def authenticate_client(request: Request):
    header = request.headers.get("Authorization", "")
    if not header.startswith("Bearer "):
        return None
    try:
        payload = jwt.decode(header[7:].strip(), JWT_SECRET, algorithms=[JWT_ALGORITHM])
    except JWTError:
        return None
    client_id = payload.get("client_id")
    if client_id not in CLIENTS:
        return None
    client = dict(CLIENTS[client_id])
    if isinstance(payload.get("scope"), str):
        client["scopes"] = payload["scope"].split()
    return client

def create_demo_token(client_id: str, scopes=None):
    if client_id not in CLIENTS:
        raise ValueError("Unknown demo client")
    payload = {"client_id": client_id, "scope": " ".join(scopes or CLIENTS[client_id]["scopes"])}
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)
