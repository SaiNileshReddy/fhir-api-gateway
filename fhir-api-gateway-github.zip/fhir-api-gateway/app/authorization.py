METHOD_TO_OPERATION = {"GET": "read", "POST": "write", "PUT": "write", "DELETE": "delete"}

def is_allowed(client, method: str, resource_type: str) -> bool:
    operation = METHOD_TO_OPERATION.get(method)
    return bool(operation and f"{resource_type}.{operation}" in client.get("scopes", []))
