import os, time
from collections import defaultdict, deque

class RateLimiter:
    def __init__(self, max_requests=100, window_seconds=60):
        self.max_requests, self.window_seconds = max_requests, window_seconds
        self.requests = defaultdict(deque)
    def allow(self, client_id):
        now = time.monotonic(); q = self.requests[client_id]
        while q and now - q[0] >= self.window_seconds: q.popleft()
        if len(q) >= self.max_requests: return False
        q.append(now); return True

rate_limiter = RateLimiter(int(os.getenv("RATE_LIMIT", "100")), 60)
