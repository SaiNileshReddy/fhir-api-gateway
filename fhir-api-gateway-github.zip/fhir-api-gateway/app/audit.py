import json, logging
from datetime import datetime, timezone
logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("fhir_audit")

def audit_log(request, client_id, decision, status, resource_type, resource_id=None):
    logger.info(json.dumps({
        "timestamp": datetime.now(timezone.utc).isoformat(), "client_id": client_id,
        "method": request.method, "path": request.url.path, "resource_type": resource_type,
        "resource_id": resource_id, "decision": decision, "status": status
    }))
