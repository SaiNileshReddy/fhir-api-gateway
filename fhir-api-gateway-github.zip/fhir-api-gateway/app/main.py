from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from .auth import authenticate_client
from .authorization import is_allowed
from .rate_limiter import rate_limiter
from .fhir_validator import validate_fhir_request
from .audit import audit_log
from .sandbox_store import get_resource, search_resources

app = FastAPI(title="FHIR API Gateway", version="1.0.0")

@app.get("/health")
def health():
    return {"status": "ok", "service": "fhir-api-gateway"}

@app.api_route("/fhir/{resource_type}", methods=["GET", "POST"])
@app.api_route("/fhir/{resource_type}/{resource_id}", methods=["GET", "PUT", "DELETE"])
async def fhir_gateway(resource_type: str, request: Request, resource_id: str | None = None):
    method = request.method
    client = authenticate_client(request)
    if not client:
        audit_log(request, "anonymous", "DENIED", 401, resource_type, resource_id)
        return fhir_error(401, "Authentication required", "security")

    if not rate_limiter.allow(client["client_id"]):
        audit_log(request, client["client_id"], "DENIED", 429, resource_type, resource_id)
        return fhir_error(429, "Rate limit exceeded", "throttled")

    if not is_allowed(client, method, resource_type):
        audit_log(request, client["client_id"], "DENIED", 403, resource_type, resource_id)
        return fhir_error(403, "Client is not authorized for this operation", "forbidden")

    body = None
    if method in {"POST", "PUT"}:
        try:
            body = await request.json()
        except Exception:
            return fhir_error(400, "Request body must be valid JSON", "invalid")
        validation = validate_fhir_request(body, resource_type, method)
        if not validation["valid"]:
            return fhir_error(400, validation["message"], "invalid")

    if method == "GET":
        result = search_resources(resource_type) if resource_id is None else get_resource(resource_type, resource_id)
        if result is None:
            audit_log(request, client["client_id"], "ALLOWED", 404, resource_type, resource_id)
            return fhir_error(404, f"{resource_type}/{resource_id} not found", "not-found")
        audit_log(request, client["client_id"], "ALLOWED", 200, resource_type, resource_id)
        return result

    if method == "POST":
        audit_log(request, client["client_id"], "ALLOWED", 201, resource_type, resource_id)
        return JSONResponse(status_code=201, content=body)
    if method == "PUT":
        audit_log(request, client["client_id"], "ALLOWED", 200, resource_type, resource_id)
        return JSONResponse(status_code=200, content=body)
    if method == "DELETE":
        audit_log(request, client["client_id"], "ALLOWED", 204, resource_type, resource_id)
        return JSONResponse(status_code=204, content=None)


def fhir_error(status_code: int, diagnostics: str, code: str):
    return JSONResponse(status_code=status_code, content={
        "resourceType": "OperationOutcome",
        "issue": [{"severity": "error", "code": code, "diagnostics": diagnostics}]
    })
