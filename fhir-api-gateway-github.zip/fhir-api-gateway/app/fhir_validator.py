REQUIRED = {"Patient": ["resourceType", "id"], "Observation": ["resourceType", "id", "status", "code"]}

def validate_fhir_request(body, expected_resource_type, method):
    if not isinstance(body, dict): return {"valid": False, "message": "FHIR resource must be a JSON object"}
    if body.get("resourceType") != expected_resource_type:
        return {"valid": False, "message": f"resourceType must be '{expected_resource_type}'"}
    missing = [x for x in REQUIRED.get(expected_resource_type, ["resourceType"]) if x not in body]
    if missing: return {"valid": False, "message": f"Missing required demo fields: {', '.join(missing)}"}
    if method == "PUT" and not body.get("id"): return {"valid": False, "message": "PUT requests require an id"}
    return {"valid": True, "message": "Valid"}
