from copy import deepcopy
DATA = {
    "Patient": {
        "123": {"resourceType":"Patient","id":"123","active":True,"name":[{"use":"official","family":"Example","given":["Alex"]}],"gender":"unknown"},
        "456": {"resourceType":"Patient","id":"456","active":True,"name":[{"use":"official","family":"Demo","given":["Jordan"]}],"gender":"unknown"},
    },
    "Observation": {
        "obs-001": {"resourceType":"Observation","id":"obs-001","status":"final","code":{"coding":[{"system":"http://loinc.org","code":"8310-5","display":"Body temperature"}]},"valueQuantity":{"value":36.8,"unit":"C"}}
    }
}

def get_resource(resource_type, resource_id):
    r = DATA.get(resource_type, {}).get(resource_id)
    return deepcopy(r) if r else None

def search_resources(resource_type):
    resources = list(DATA.get(resource_type, {}).values())
    return {"resourceType":"Bundle","type":"searchset","total":len(resources),"entry":[{"resource":deepcopy(r)} for r in resources]}
